# Pump Research Lab v4 — Quant Terminal

Mobile-first research dashboard for token-pool discovery, rough momentum scoring, CoinDCX futures data checks, paper-alert logging, CSV export, and an exploratory candle test.

## Run
1. Extract the ZIP.
2. Open `index.html` in a modern browser, or host the folder as a static website (for example GitHub Pages).
3. Tap **Scan now** and inspect the Pipeline monitor.
4. If the browser blocks a public endpoint with CORS, run the app through a small backend proxy; never put exchange private keys in front-end code.

## Important limitations
- This is a research prototype, not a trading system and not a profitability claim.
- Live API compatibility, CORS access, rate limits, response schemas, and CoinDCX instrument mapping must be tested in the target browser.
- DEX discovery data does not prove a corresponding CoinDCX futures market exists.
- Symbol matching is approximate and is explicitly labeled a possible match.
- Order-book spread/depth is not yet verified for every candidate; the UI reports this as not checked.
- The backtest is an exploratory breakout baseline, not a robust walk-forward/out-of-sample study. It does not model exact fills, funding, or realistic slippage; the user-supplied round-trip cost is a simple deduction.
- Browser localStorage paper logs stay on that browser/device. Auto-scan stops when the page is closed or suspended.
- No exchange credentials are requested. No real orders are sent.
